
package com.zybooks.enhancedeventtrack;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SignUp extends AppCompatActivity{

    // Variables for EditText
    private EditText emailEdit, passwordEdit, confirmEdit;
    // Variable for button
    private Button createButton;
    // Variable for DB
    private SignUpDBHelper signUpDBHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);

        // Initialize variables
        emailEdit = findViewById(R.id.SignupEditTextEmail);
        passwordEdit = findViewById(R.id.SignupEditTextPassword);
        confirmEdit = findViewById(R.id.SignupEditTextConfirm);
        createButton = findViewById(R.id.CreateAccountButton);

        // Create new signupDBHelper class
        signUpDBHelper = new SignUpDBHelper(SignUp.this);

        // On click listener for button
        createButton.setOnClickListener(new View.OnClickListener()  {
            @Override
            public void onClick(View v){
                // Get data from edit text fields
                String email = emailEdit.getText().toString();
                String password = passwordEdit.getText().toString();
                String confirm = confirmEdit.getText().toString();

                // Validate text fields are not empty
                if (email.isEmpty() && password.isEmpty() && confirm.isEmpty()){
                    Toast.makeText(SignUp.this, "Please fill in all required fields.", Toast.LENGTH_SHORT).show();
                    // Check if passwords match
                } else if (!password.equals(confirm)) {
                    Toast.makeText(SignUp.this, "Passwords do not match. ", Toast.LENGTH_SHORT).show();
                } else {
                    // Conditions are met, add user
                    signUpDBHelper.addNewUser(email, password);
                    Toast.makeText(SignUp.this, "User ID successfully Created.", Toast.LENGTH_SHORT).show();
                    emailEdit.setText("");
                    passwordEdit.setText("");
                }
            }
        });
    }
}
