package com.zybooks.enhancedeventtrack;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class EventDBHelper extends SQLiteOpenHelper {

    // Variables to create database
    private static final String DATABASE_NAME = "eventdb";
    private static final int DATABASE_VERSION = 2;
    private static final String TABLE_NAME = "event";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_DETAILS = "details";

    // Constructor for database handler
    public EventDBHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Create DB by running SQLite query
    @Override
    public void onCreate(SQLiteDatabase db){
        String query = "CREATE TABLE " + TABLE_NAME + " ( "
                + COLUMN_ID + "INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_DATE + " DATE,"
                + COLUMN_NAME + " TEXT,"
                + COLUMN_DETAILS + " TEXT)";
        // Execute query
        db.execSQL(query);
    }

    public void addEvents(ArrayList<Event> events) {
        SQLiteDatabase db = this.getWritableDatabase();
        for (Event event : events) {
            ContentValues values = new ContentValues();
            values.put(COL_DATE, event.getDate());
            values.put(COL_NAME, event.getName());
            values.put(COL_DETAILS, event.getDetails());
            db.insert(TABLE_USERS, null, values);
        }
        db.close();
    }

    // Method for upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        // Or drop if already exists
        db.execSQL("Drop table if exists " + TABLE_USERS);
        // Create
        onCreate(db);
    }



    public void updateEvent(int id, String newDate, String newName, String newDetails) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_DATE, newDate);
        values.put(COL_NAME, newName);
        values.put(COL_DETAILS, newDetails);

        // Update the event with the specified ID
        int rowsAffected = db.update(TABLE_USERS, values, COL_ID + " = ?", new String[]{String.valueOf(id)});

        if (rowsAffected > 0) {
            System.out.println("Event " + id + " updated successfully.");
        } else {
            System.out.println("Event " + id + " not found.");
        }
        db.close();
    }

    public void deleteEvent(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Delete the event with the specified ID
        int rowsDeleted = db.delete(TABLE_USERS, COL_ID + " = ?", new String[]{String.valueOf(id)});

        if (rowsDeleted > 0) {
            System.out.println("Event " + id + " deleted successfully.");
        } else {
            System.out.println("Event " + id + " not found.");
        }
        db.close();
    }
}

