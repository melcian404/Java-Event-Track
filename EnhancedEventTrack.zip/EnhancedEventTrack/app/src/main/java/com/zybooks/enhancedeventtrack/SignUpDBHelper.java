package com.zybooks.enhancedeventtrack;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;

public class SignUpDBHelper extends SQLiteOpenHelper {

    // Variables to create database
    private static final String DATABASE_NAME = "userdb";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "signup";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";

    // DB Constructor
    public SignUpDBHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Create DB by running SQLite query
    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " ( "
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_EMAIL + " TEXT,"
                + COLUMN_PASSWORD + " TEXT)";
        // Execute query
        db.execSQL(query);
    }

    // Add user info into DB
    public void addNewUser(String userEmail, String userPassword){
        // Call writable method
        SQLiteDatabase db = this.getWritableDatabase();
        // Variable for content values
        ContentValues values = new ContentValues();

        // Pass values in with key and value pair
        values.put(COLUMN_EMAIL, userEmail);
        values.put(COLUMN_PASSWORD, userPassword);

        // Insert values into table
        db.insert(TABLE_NAME, null, values);

        // Close DB
        db.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        // Checks if table already exists
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}
